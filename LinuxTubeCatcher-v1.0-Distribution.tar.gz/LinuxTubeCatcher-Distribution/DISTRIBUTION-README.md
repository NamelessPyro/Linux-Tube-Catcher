# Linux Tube Catcher - Distribution Package

**A complete video downloader and converter for Linux systems**  
*Created by NamelessPyro*

## 🎯 What is Linux Tube Catcher?

Linux Tube Catcher is a powerful, user-friendly application that brings the functionality of the popular Windows aTube Catcher to Linux systems. Download and convert videos from YouTube, Vimeo, and 1000+ other platforms with ease!

## ✨ Key Features

- 📺 **Download from 1000+ platforms** - YouTube, Vimeo, Dailymotion, Facebook, Instagram, Twitter, and more
- 🎵 **Full playlist support** - Download entire playlists with smart organization
- 🎬 **High-quality mode** - Downloads best quality first, then intelligently scales for optimal results
- 🔄 **Format conversion** - Convert to MP4, AVI, MKV, WebM, MOV
- 🎶 **Audio extraction** - Extract to MP3, WAV, AAC, OGG, M4A
- 📱 **Modern GUI** - Clean, intuitive interface built with Python tkinter
- 📊 **Progress tracking** - Real-time download progress with detailed logging
- 📁 **Smart organization** - Automatic folder creation and file naming

## 🚀 One-Click Installation

### Super Easy Installation (Recommended)

1. **Download this folder** or clone the repository
2. **Open a terminal** in this folder
3. **Run the installer**:
   ```bash
   ./easy-install.sh
   ```
4. **That's it!** The installer will handle everything automatically

### What the installer does:

- ✅ Checks system compatibility
- ✅ Installs all required system packages (Python, FFmpeg, etc.)
- ✅ Creates isolated Python environment
- ✅ Installs all Python dependencies
- ✅ Sets up desktop launcher
- ✅ Adds to applications menu
- ✅ Creates command-line launcher
- ✅ Tests everything works

## 🖥️ System Requirements

- **OS**: Linux Mint, Ubuntu, Debian, Pop!_OS, or compatible
- **Architecture**: x64 (most modern systems)
- **RAM**: 512MB minimum, 1GB recommended
- **Storage**: 500MB for installation + space for downloads
- **Internet**: Required for downloading videos

## 🎮 How to Use

### After Installation:

1. **From Applications Menu**: Search for "Linux Tube Catcher"
2. **From Terminal**: Type `linux-tube-catcher`
3. **Usage**:
   - Paste any video or playlist URL
   - Choose quality and format
   - Select download location
   - Click Download!

### Supported URLs:
```
✅ Single videos:
https://www.youtube.com/watch?v=VIDEO_ID
https://vimeo.com/VIDEO_ID

✅ Playlists:
https://www.youtube.com/playlist?list=PLAYLIST_ID
https://vimeo.com/showcase/SHOWCASE_ID

✅ And 1000+ more platforms!
```

## 🛠️ Advanced Features

- **Playlist Mode**: Download entire playlists with numbering and organization
- **High-Quality Scaling**: Download 4K/1080p then scale to 720p for better quality
- **Batch Processing**: Queue multiple downloads
- **Format Conversion**: Convert between video/audio formats
- **Quality Selection**: Choose from 144p to 4K (best available)

## 🔧 Troubleshooting

If you encounter issues:

1. **Re-run the installer**: `./easy-install.sh`
2. **Check system compatibility**: The installer will warn about unsupported systems
3. **Manual installation**: Follow the detailed README.md in the package

## 🗑️ Uninstallation

To remove Linux Tube Catcher:
```bash
./uninstall.sh
```

This will cleanly remove all application files while leaving system dependencies intact.

## 📦 Package Contents

```
LinuxTubeCatcher-Distribution/
├── easy-install.sh           # One-click installer
├── uninstall.sh             # Clean uninstaller
├── linux_tube_catcher.py    # Main application
├── requirements.txt         # Python dependencies
├── icon.png                # Application icon
├── README.md               # Full documentation
└── DISTRIBUTION-README.md  # This file
```

## 🆚 Comparison with Original aTube Catcher

| Feature | Windows aTube Catcher | Linux Tube Catcher |
|---------|----------------------|-------------------|
| Video Download | ✓ | ✓ Enhanced |
| Playlist Support | ✓ | ✓ Better organized |
| Audio Extraction | ✓ | ✓ More formats |
| Format Conversion | ✓ | ✓ FFmpeg powered |
| High-Quality Mode | ✗ | ✓ Unique feature |
| Modern Interface | Dated | ✓ Clean & modern |
| Cross-platform | Windows only | Linux native |
| Open Source | ✗ | ✓ MIT License |

## 💝 Support & Contributing

- **Issues**: Report bugs or request features
- **Documentation**: Full README.md included
- **License**: MIT License - free and open source
- **Creator**: NamelessPyro

## 🎉 Quick Start

1. Download this package
2. Run: `./easy-install.sh`
3. Launch from applications menu
4. Paste a YouTube URL and click Download!

**Enjoy downloading videos on Linux with the power and simplicity of aTube Catcher!**

---
*Linux Tube Catcher - Bringing aTube Catcher to Linux*  
*Created by NamelessPyro - 2025*
